# Crops&Weeds 3 > 2024-12-24 5:37pm
https://universe.roboflow.com/matorovskii/crops-weeds-3

Provided by a Roboflow user
License: CC BY 4.0

